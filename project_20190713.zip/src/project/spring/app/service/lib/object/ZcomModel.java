package project.spring.app.service.lib.object;

import project.spring.app.a.lib.object.CommonModel;

public class ZcomModel extends CommonModel {
	

}

