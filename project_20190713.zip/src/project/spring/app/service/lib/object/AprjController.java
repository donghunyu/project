package project.spring.app.service.lib.object;

public class AprjController extends ZcomController {


}
