package project.spring.app.service.lib.object;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import project.spring.app.a.lib.object.CommonService;

public class AprjSchedul extends CommonService {
	
	protected Log    logger      = LogFactory.getLog(getClass());
	
}

